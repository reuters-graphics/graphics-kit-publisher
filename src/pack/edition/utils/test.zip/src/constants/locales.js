export const VALID_LOCALES = ['en', 'ar', 'fr', 'es', 'de', 'it', 'ja', 'pt', 'ru'];
