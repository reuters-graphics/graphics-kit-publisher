export const editionReadme = `REUTERS GRAPHICS ${new Date().getFullYear()}`;
