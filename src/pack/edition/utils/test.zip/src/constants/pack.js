export const DEFAULT_PACK_LOCALE = 'en';
export const DEFAULT_PACK_METADATA_FILE = 'content.json';
export const DEFAULT_PACK_TITLE_PROP = 'SEOTitle';
export const DEFAULT_PACK_DESCRIPTION_PROP = 'SEODescription';
