export const DEFAULT_WARN_IMAGE_SIZE = 200; // in KB
