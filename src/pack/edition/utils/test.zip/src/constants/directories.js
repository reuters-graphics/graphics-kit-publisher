export const DEFAULT_PACK_DIR = 'graphics-pack';
export const DEFAULT_DIST_DIR = 'dist';
export const DEFAULT_ASSETS_DIR = 'media-assets';
export const DEFAULT_IMAGES_DIR = 'src/statics/images';
export const DEFAULT_LOCALES_DIR = 'locales';
