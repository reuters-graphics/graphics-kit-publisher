export const validHomepageHostnames = ['www.reuters.com', 'graphics.reuters.com'];
