export const PREVIEW_HOST = 'graphics.thomsonreuters.com';
export const PREVIEW_ORIGIN = `https://${PREVIEW_HOST}`;
